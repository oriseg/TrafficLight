﻿namespace TrafficLight.Models
{
    static class Strings
    {
        public const string changeLightText = "Change Light";
    }
}
